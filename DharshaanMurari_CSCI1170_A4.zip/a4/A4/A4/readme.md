# CSCI 1170: Intro to Web Design and Development, Fall 2024

## Student Info

Name: Dharshaan Murari

Student ID: B00992771

Email: dh992771@dal.ca

## Assignment 4 Deliverable

This is part of a deliverable for Assignment 4 during the Fall 2024 term.

## Milestone Submission

In order to recieve a complete on the milestone submission, a meaningful attempt in starting the assignment needs to be made. Additionally, please remember to add your student information to the above block.

## Changes Made to index.html

If you made changes to the provided index.html page, please list them here and explain why the changes were made. Did you add an id? class? div container? Something else? Why did you need to change something to support the styling? Could you have done the styling without changing the HTML?

Change #1: I added a footer that shows the time and date.

Reason for change: I feel like adding the date and time is important for an academic timetable as enrollment varies very differently from day to day, and even minute to minute. Having a indicator of the time on the website can better reflect the course enrollment as any given time and date.

Change #2: I moved the search bar from the main section to the header.

Reason for change: Made it easier to implement styling that reflects the wireframes I made.

## References and Citations

1. date object, along with toLocaleTimeString functionality, used in footer is taken from https://www.geeksforgeeks.org/how-to-get-current-time-in-javascript/ when I searched up "how to display current time in javascript" on Google. Accessed on Nov 24, 2024.

2. .join syntax and function found on https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/join as an alternative to a for loop when I searched up "array to string javascript with separator" on Google. Accessed on Nov 24, 2024

3. .filter arrow notation found on https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter when I search "array filter js" on Google. Accessed November 30, 2024.

4. Syntax for rounding corners of the button. found on https://www.w3schools.com/howto/howto_css_round_buttons.asp when I search "rounded button css" on Google. Accessed on November 30, 2024
