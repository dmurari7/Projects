import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FantasyBasketballHelper
{
    public static void main(String[] args)
    {
        //Creates an ArrayList to store Player objects
        ArrayList<Player> playerList = new ArrayList<>();

        //Scraps webpage. Source: https://www.scrapingbee.com/blog/java-parse-html-jsoup/
        Document website;
        try
        {
            website = Jsoup.connect("https://www.fantasypros.com/nba/rankings/overall.php").get();
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }

        //Selects correct table and rows from website
        Element playerTable = website.select("table").get(0);
        Elements playerTableBody = playerTable.select("tbody");
        Elements playerRows = playerTableBody.select("tr");
        for (Element playerRow : playerRows)
        {
            /* Extracts the player information from the table.
            Source: https://jsoup.org/cookbook/extracting-data/attributes-text-html */
            String name = playerRow.select("a").get(0).text();
            String position = playerRow.select("small").get(0).text();
            int ranking = Integer.parseInt(playerRow.select("td").get(0).text());

            //Creates a new Player object and add it to the list
            playerList.add(new Player(name, position, ranking));
        }

        System.out.println("Welcome to the Fantasy Basketball Helper!" +
                "\nThis program is meant to be used along side whatever device you are using during your fantasy draft."
                 + "\nOur algorithm will pick the best player for you and your positional needs for each round!\n");

        //variable used to simulate each round
        boolean goToNextRound = true;

        //unless the user doesn't want to go to the next round, the loop iterates
        while (goToNextRound)
        {
            //variable used later to determine the best pick for each round
            Player bestPlayer;

            // Get the drafted player names from the user
            Scanner userInput = new Scanner(System.in);
            System.out.println("Enter the full names of already-drafted players," +
                    "including your own pick from the previous round (comma-separated):");
            String draftedPlayersInput = userInput.nextLine();
            /* separates each player by a comma. If the user doesn't enter a valid player, it won't remove anything.
            Source: https://www.geeksforgeeks.org/split-string-java-examples/ */
            String[] draftedPlayerNames = draftedPlayersInput.split(",");

            // Removes drafted players from the available player list
            playerList = removeDraftedPlayers(playerList, draftedPlayerNames);

            System.out.println("Is there any specific position you need your player to play?" +
                    "\nEnter PG, SG, SF, PF, C or ANY for the required position:");
            String neededPosition = userInput.nextLine();

            /* calls appropriate method based on whether the user wants a specific position.
            If the input is not any of the options, it defaults to ANY.*/
            if (neededPosition.equalsIgnoreCase("PG") || neededPosition.equalsIgnoreCase("SG") ||
                    neededPosition.equalsIgnoreCase("SF") || neededPosition.equalsIgnoreCase("PF")
                    || neededPosition.equalsIgnoreCase("C"))
            {
                bestPlayer = getBestPlayer(playerList, neededPosition.toUpperCase());
            }
            else
            {
                bestPlayer = getBestPlayer(playerList);
            }

            // Prints the best player information
            if (bestPlayer != null)
            {
                System.out.println("Best Player to Draft:");
                System.out.println(bestPlayer.getName() + " - " + "(Team & Position: " + bestPlayer.getPosition()
                        + ", Ranking: " + bestPlayer.getRanking() + ")");
            } else
            {
                System.out.println("\nNo available players to draft.");
            }

            // Prompts user whether to continue drafting or end the program
            System.out.println("\nDo you want to continue drafting to the next round? (y/n):");
            String input = userInput.nextLine();
            if (input.equalsIgnoreCase("n"))
            {
                System.out.println("Drafting completed.");
                goToNextRound = false;
            }
        }
    }
    // Method to remove drafted players from the available player list
    private static ArrayList<Player> removeDraftedPlayers(ArrayList<Player> playerList, String[] draftedPlayerNames)
    {
        for (String draftedPlayerName : draftedPlayerNames)
        {
            for (Player player : playerList)
            {
                if (player.getName().equalsIgnoreCase(draftedPlayerName.trim()))
                {
                    playerList.remove(player);
                    break;
                }
            }
        }
        return playerList;
    }

    // Method to get the best player based on ranking and whatever position the user enters
    private static Player getBestPlayer(ArrayList<Player> playerList, String position) {
        ArrayList<Player> positionPlayerList = new ArrayList<>();
        if (playerList.isEmpty())
        {
            return null;
        }
        for (Player player : playerList)
        {
            if (player.getPosition().substring(3).indexOf(position) > -1)
            {
                positionPlayerList.add(player);
            }
        }
        Player bestPlayer = positionPlayerList.get(0);
        for (Player player : positionPlayerList)
        {
            if (player.getRanking() < bestPlayer.getRanking())
            {
                bestPlayer = player;
            }
        }
        return bestPlayer;
    }

    // Method to get the best player based on ranking
    private static Player getBestPlayer(List<Player> playerList) {
        if (playerList.isEmpty())
        {
            return null;
        }
        Player bestPlayer = playerList.get(0);
        for (Player player : playerList)
        {
            if (player.getRanking() < bestPlayer.getRanking())
            {
                bestPlayer = player;
            }
        }
        return bestPlayer;
    }

    //class used to store player information
    static class Player
    {
        private String name;
        private String position;
        private int ranking;

        public Player(String name, String position, int ranking)
        {
            this.name = name;
            this.position = position;
            this.ranking = ranking;
        }

        public String getName()
        {
            return name;
        }

        public String getPosition()
        {
            return position;
        }

        public int getRanking()
        {
            return ranking;
        }
    }
}



