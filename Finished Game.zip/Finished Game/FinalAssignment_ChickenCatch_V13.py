#imports new functions to draw and display the elements of the game. Ex: screen, player, ball and text. Sources: http://www.cse.msu.edu/~ldillon/cse-ctl/Spring2015/Meeting07/turtleCheatSheet.pdf, https://realpython.com/beginners-guide-python-turtle/, https://www.geeksforgeeks.org/create-pong-game-using-python-turtle/
import turtle

#imports new functions for randomly generated outputs. I am using it is random.randrange().
import random

#imports new functions that are time related. I am using it for time.sleep(). Source: https://www.geeksforgeeks.org/sleep-in-python/.
import time

#imports all the functions from the tkinter module, which is used to create GUIs.
from tkinter import *

def chickenCatchGame():

    #allows the variable to be accessed throughout the program
    global window

    global canvas

    #deletes the title screen 
    window.destroy()

    #sets the level to 1    
    level = 1

    #randomly selects an inital x coordinate for the first ball between -220 and 220 with a step of 20 pixels. 
    randomStartingPosition = random.randrange(-220, 220, 20)

    #randomly selects an inital x coordinate for the second ball between -220 and 220 with a step of 20 pixels.
    randomStartingPositionTwo = random.randrange(-220, 220, 20)

    #randomly selects an inital x coordinate for the third ball between -220 and 220 with a step of 20 pixels.
    randomStartingPositionThree = random.randrange(-220, 220, 20)

    #randomly selects an inital x coordinate for the fourth ball between -220 and 220 with a step of 20 pixels.
    randomStartingPositionFour = random.randrange(-220, 220, 20)

    #randomly selects an intial speed for the first ball between -4 and -1. (The range is negative because this variable is also for the direction it travels, so a negative number ensures it travels downward.)
    randomStartingSpeed = random.randrange(-4,-1)

    #randomly selects an intial speed for the second ball between -4 and -1.
    randomStartingSpeedTwo = random.randrange(-4,-1)

    #randomly selects an intial speed for the third ball between -4 and -1.
    randomStartingSpeedThree = random.randrange(-4,-1)

    #randomly selects an intial speed for the fourth ball between -4 and -1.
    randomStartingSpeedFour = random.randrange(-4,-1)

    #creates a drawing window for the game
    screen = turtle.Screen()

    #allowing the turtle screen to be opened and closed multiple times. Source: https://stackoverflow.com/questions/46796846/python-turtle-terminator-error
    turtle.TurtleScreen._RUNNING=True

    #changes the width and the height of the screen
    screen.setup(width = 700, height = 450)

    #takes a .gif file in the same path as the program and adds it to the game as a turtle. Source: https://pythonguides.com/attach-image-to-turtle-python/
    for counter in range(1,6):

        screen.addshape("ChickenCatchBeginningCutsceneImage" + str(counter) + ".gif")

    for counter in range(1,11):
        
        screen.addshape("ChickenCatchEndingCutsceneImage" + str(counter) + ".gif")

    
    screen.addshape("ChickenCatchDrumstickImage.gif")

    screen.addshape("ChickenCatchPlayerImageRight.gif")

    screen.addshape("ChickenCatchPlayerImageLeft.gif")

    screen.addshape("ChickenCatchGameOverImage.gif")

    screen.addshape("ChickenCatchGameOverTextImage.gif")

    screen.addshape("ChickenCatchLevelOneText.gif")
    
    #creates a turtle to display the starting cutscene
    startingCutscene = turtle.Turtle()

    for counter in range(1,6):

        #sets the shape of the turtle as the image
        startingCutscene.shape("ChickenCatchBeginningCutsceneImage" + str(counter) + ".gif")

        #pauses the program for a set amount of seconds. Ex: time.sleep(5) == 5 seconds
        time.sleep(2)

    #clears the turtle screen
    screen.clear()

    #sets the background colour of the screen
    screen.bgcolor("black")

    #displays the text that says "Level One"
    levelText = turtle.Turtle()

    levelText.shape("ChickenCatchLevelOneText.gif")

    time.sleep(2)

    screen.clear()

    #sets the title of the turtle screen
    screen.title("Chicken Catch")

    #sets the background of the turtle screen as an image
    screen.bgpic("ChickenCatchBackgroundImage.gif")

    screen.setup(width = 500, height = 675)


    #creates a turtle for the Mr. Flanagan Sprite that the player controls
    player = turtle.Turtle()

    player.speed(0)

    player.shape("ChickenCatchPlayerImageRight.gif")

    player.shapesize(stretch_wid = 0.75, stretch_len = 3.5)

    player.penup()

    player.goto(0, -275)

    #creates a turtle for the first food item that the player must catch
    ball = turtle.Turtle()

    ball.shape("ChickenCatchDrumstickImage.gif")

    ball.penup()

    ball.hideturtle()

    #goes to a random inital position each time the game starts
    ball.goto(randomStartingPosition, 360)

    ball.showturtle()

    #the 'apple' falls at the random speed
    ballydirection = randomStartingSpeed 

    #clones the attributes of ball and assigns it ballTwo
    ballTwo = ball.clone()

    ballTwo.hideturtle()

    ballTwo.goto(randomStartingPositionTwo, 360)

    ballTwo.showturtle()

    ballTwoydirection = randomStartingSpeedTwo

    #clones the attributes of ball and assigns it ballThree
    ballThree = ball.clone()

    ballThree.hideturtle()

    ballThree.goto(randomStartingPositionThree, 360)

    ballThree.showturtle()

    ballThreeydirection = randomStartingSpeedThree

    #clones the attributes of ball and assigns it ballFour
    ballFour = ball.clone()

    ballFour.hideturtle()

    ballFour.goto(randomStartingPositionFour, 360)

    ballFour.showturtle()

    ballFourydirection = randomStartingSpeedFour

    #creates a turtle for the initial score
    scoreText = turtle.Turtle()

    scoreText.color("#FF69B4")

    scoreText.penup()

    scoreText.hideturtle()

    scoreText.goto(0, 250)

    #writes 'Score: 0' in the center of the screen
    scoreText.write("Score: 0", align = 'center', font = ("Times New Roman", 16, "bold"))


    #creates a function that makes the player move left 20 pixels
    def playerLeft():

        player.shape("ChickenCatchPlayerImageLeft.gif")

        #assigns the player's current x coordinate to 'x'
        x = player.xcor()

        #takes that position and subtracts it by 20 pixels
        x -= 20

        #sets the position of the player to the new value of 'x'
        player.setx(x)


    #creates a function that makes the player move right 20 pixels
    def playerRight():

        player.shape("ChickenCatchPlayerImageRight.gif")

        #assigns the player's current x coordinate to 'x'
        x = player.xcor()

        #takes the current position of the player and adds twenty to it
        x += 20

        #sets the position of the player to the new value of 'x'
        player.setx(x)


    #creates a function for the game over screen
    def gameOver():

        global window

        global canvas

        screen.clear()

        screen.bgcolor("black")

        #creates a turtle for the text of the game over screen 
        gameOverTitleText = turtle.Turtle()

        gameOverTitleText.penup()

        gameOverTitleText.shape("ChickenCatchGameOverTextImage.gif")

        gameOverTitleText.goto(0,220)

        #writes 'Game Over!' in the center of the screen
        gameOverImage = turtle.Turtle()

        gameOverImage.penup()

        gameOverImage.shape("ChickenCatchGameOverImage.gif")

        gameOverImage.goto(0,0)

        #displays the player's current score
        gameOverText = turtle.Turtle()

        gameOverText.penup()

        gameOverText.hideturtle()
        
        gameOverText.goto(0, -200)

        gameOverText.color("#FF69B4")

        gameOverText.write("Your score was " + str(score) + " points", align = "center", font = ("Arial", 25, "bold"))

        time.sleep(3)

    #----------------------------------------------------------------------------------------------------------------------------------------------------------------
    #Segment of code displays the title screen for replayabilty 

        #closes the turtle screen
        screen.bye()

        #creates a window used for GUIs
        window = Tk()

        #sets the dimensions of the window
        window.geometry("500x725")

        #displays the title of the window
        window.title("Chicken Catch")

        #imports an image from the same path as the program
        bg = PhotoImage(file = "ChickenCatchTitleScreenBackground_V1.gif")

        #creates a canvas
        canvas = Canvas(width = 500, height = 725)

        #displays the 'bg' image
        canvas.create_image(0, 0, image = bg, anchor = "nw")

        #creates a button that starts the game
        gameButton = Button(text = "Play Game!", command = chickenCatchGame, width = 25, height = 3, fg = "black", bg = "#FF69B4")

        #places the button on the canvas
        gameButtonCanvas = canvas.create_window(170, 250, anchor = "nw", window = gameButton)

        #creates a button that goes to the "Instructions" page
        instructionsButton = Button(text = "Instructions", command = instructionScreen, width = 25, height = 3, fg = "black", bg = "#FF69B4")

        instructionsButtonCanvas = canvas.create_window(170, 350, anchor = "nw", window = instructionsButton)

        #creates a button that goes to the "Credits" page
        creditsButton = Button(text = "Credits", command = creditScreen, width = 25, height = 3, fg = "black", bg = "#FF69B4")

        creditsButtonCanvas = canvas.create_window(170, 450, anchor = "nw", window = creditsButton)

        #creates a button that exits the program
        quitButton = Button(text = "Quit Game", command = window.destroy, width = 25, height = 3, fg = "black", bg = "#FF69B4")

        quitButtonCanvas = canvas.create_window(170, 550, anchor = "nw", window = quitButton)

        #places the canvas
        canvas.grid(row = 0, column = 0)

        #keeps the window running even when the program is finished.
        window.mainloop()


    def ballMovement(x,y,z):

        #sets a new speed for the ball
        x = y

        #hides the ball
        z.hideturtle()

        #sets the ball to a new random position
        z.goto(randomPosition, 350)

        #shows the ball again
        z.showturtle()


    #collect key-events like onkeypress(). Source: https://docs.python.org/3/library/turtle.html#turtle.listen                  
    screen.listen()

    #whenever the left arrow is pressed, the function 'playerLeft' is called.
    screen.onkeypress(playerLeft, "Left")

    #whenever the right arrow is pressed, the function 'playerRight' is called.
    screen.onkeypress(playerRight, "Right")

    #initializes the variable 'score' to 0
    score = 0

    #creates a neverending loop
    while True:

        #After the ball hits the basket, it randomly selects a new x coordinate for the first ball between -220 and 220 with a step of 20 pixels.
        randomPosition = random.randrange(-220, 220, 20)

        #After the ball hits the basket, it randomly selects a new x coordinate for the second ball between -220 and 220 with a step of 20 pixels.
        randomPositionTwo = random.randrange(-220, 220, 20)

        #After the ball hits the basket, it randomly selects a new x coordinate for the third ball between -220 and 220 with a step of 20 pixels.
        randomPositionThree = random.randrange(-220, 220, 20)

        #After the ball hits the basket, it randomly selects a new x coordinate for the fourth ball between -220 and 220 with a step of 20 pixels.
        randomPositionFour = random.randrange(-220, 220, 20)
        
        #As well, it randomly selects an new speed for the first ball between -4 and -1. 
        randomSpeed = random.randrange(-4,-1)

        #it randomly selects an new speed for the second ball between -4 and -1.
        randomSpeedTwo = random.randrange(-4,-1)

        #it randomly selects an new speed for the third ball between -4 and -1.
        randomSpeedThree = random.randrange(-4,-1)

        #it randomly selects an new speed for the fourth ball between -4 and -1.
        randomSpeedFour = random.randrange(-4,-1)

        

        if level == 2:

            #As well, it randomly selects an new speed for the first ball between -7 and -1. 
            randomSpeed = random.randrange(-7,-1)

            #it randomly selects an new speed for the second ball between -7 and -1.
            randomSpeedTwo = random.randrange(-7,-1)

            #it randomly selects an new speed for the third ball between -7 and -1.
            randomSpeedThree = random.randrange(-7,-1)

            #it randomly selects an new speed for the fourth ball between -7 and -1.
            randomSpeedFour = random.randrange(-7,-1)

        if level == 3:

            #As well, it randomly selects an new speed for the first ball between -10 and -1. 
            randomSpeed = random.randrange(-10,-1)

            #it randomly selects an new speed for the second ball between -10 and -1.
            randomSpeedTwo = random.randrange(-10,-1)

            #it randomly selects an new speed for the third ball between -10 and -1.
            randomSpeedThree = random.randrange(-10,-1)

            #it randomly selects an new speed for the fourth ball between -10 and -1.
            randomSpeedFour = random.randrange(-10,-1)


        #update the screens
        screen.update()

            
        #sets the position of ball to the ball's current y coordinate + ballydirection
        ball.sety(ball.ycor()+ballydirection)

        #sets the position of ballTwo to the ball's current y coordinate + ballTwoydirection
        ballTwo.sety(ballTwo.ycor()+ballTwoydirection)

        #sets the position of ballThree to the ball's current y coordinate + ballThreeydirection
        ballThree.sety(ballThree.ycor()+ballThreeydirection)

        #sets the position of ballFour to the ball's current y coordinate + ballFourydirection
        ballFour.sety(ballFour.ycor()+ballFourydirection)

        #if the player's x coordinate is greater than 220, it sets them back within the screen's view. (collision detection with wall)
        if player.xcor() > 220:
            
            player.goto(220, -275)
            
        #if the player's x coordinate is greater than -2220, it sets them back within the screen's view.
        if player.xcor() < -220:
            
            player.goto(-220, -275)
            
        #if any of the balls hit the bottom of the screen, it shows the game over screen then closes the screen
        if ball.ycor() < -320 or ballTwo.ycor() < -320 or ballThree.ycor() < -320 or ballFour.ycor() < -320:

            gameOver()

        #if the ball's y coordinate is greater than -245 and it's x coordinate matches the player's, it will run this code.
        if ball.ycor() < -230 and ball.xcor() == player.xcor():

            ballMovement(ballydirection, randomSpeed, ball)

            #increases the variable 'score' by 25
            score += 25

            #clears what was written before by ScoreText
            scoreText.clear()

            #writes and displays the updated score
            scoreText.write("Score: " + str(score), align = 'center', font = ("Times New Roman", 16, "bold"))

        #if the ball's y coordinate is greater than -245 and it's x coordinate matches the player's, it will run this code.
        elif ballTwo.ycor() < -230 and ballTwo.xcor() == player.xcor():

            ballMovement(ballTwoydirection, randomSpeedTwo, ballTwo)

            score += 25

            scoreText.clear()

            scoreText.write("Score: " + str(score), align = 'center', font = ("Times New Roman", 16, "bold"))

        #if the ball's y coordinate is greater than -245 and it's x coordinate matches the player's, it will run this code.        
        elif ballThree.ycor() < -230 and ballThree.xcor() == player.xcor():

            ballMovement(ballThreeydirection, randomSpeedThree, ballThree)

            score += 25

            scoreText.clear()

            scoreText.write("Score: " + str(score), align = 'center', font = ("Times New Roman", 16, "bold"))

        #if the ball's y coordinate is greater than -245 and it's x coordinate matches the player's, it will run this code.
        elif ballFour.ycor() < -230 and ballFour.xcor() == player.xcor():

            ballMovement(ballFourydirection, randomSpeedFour, ballFour)

            score += 25

            scoreText.clear()

            scoreText.write("Score: " + str(score), align = 'center', font = ("Times New Roman", 16, "bold"))


        if level == 1 and score == 225:

            #sets level to 2, begins second level which makes the food and background different, and increase the food's speed
            level = 2

            screen.clear()

            screen.bgcolor("black")

            screen.addshape("ChickenCatchLevelTwoText.gif")

            levelText = turtle.Turtle()

            levelText.shape("ChickenCatchLevelTwoText.gif")

            time.sleep(2)

            screen.clear()

            #randomly selects an inital x coordinate for the first ball between -220 and 220 with a step of 20 pixels. 
            randomStartingPosition = random.randrange(-220, 220, 20)

            #randomly selects an inital x coordinate for the second ball between -220 and 220 with a step of 20 pixels.
            randomStartingPositionTwo = random.randrange(-220, 220, 20)

            #randomly selects an inital x coordinate for the third ball between -220 and 220 with a step of 20 pixels.
            randomStartingPositionThree = random.randrange(-220, 220, 20)

            #randomly selects an inital x coordinate for the fourth ball between -220 and 220 with a step of 20 pixels.
            randomStartingPositionFour = random.randrange(-220, 220, 20)

            #randomly selects an intial speed for the first ball between -6 and -1. (The range is negative because this variable is also for the direction it travels, so a negative number ensures it travels downward.)
            randomStartingSpeed = random.randrange(-7,-1)

            #randomly selects an intial speed for the second ball between -6 and -1.
            randomStartingSpeedTwo = random.randrange(-7,-1)

            #randomly selects an intial speed for the third ball between -6 and -1.
            randomStartingSpeedThree = random.randrange(-7,-1)

            #randomly selects an intial speed for the fourth ball between -6 and -1.
            randomStartingSpeedFour = random.randrange(-7,-1)

            screen.title("Chicken Catch")

            screen.bgpic("ChickenCatchBackgroundImageLevelTwo.gif")

            screen.addshape("ChickenCatchPopcornImage.gif")

            #changes the width and the height of the screen
            screen.setup(width = 500, height = 675)


            #creates a turtle for the 'basket' that the player controls
            player = turtle.Turtle()

            player.speed(0)

            player.shape("ChickenCatchPlayerImageRight.gif")

            player.shapesize(stretch_wid = 0.75, stretch_len = 3.5)

            player.penup()

            player.goto(0, -275)

            #creates a turtle for the first 'apple' that the player must catch
            ball = turtle.Turtle()

            ball.shape("ChickenCatchPopcornImage.gif")

            ball.penup()

            #goes to a random inital position each time the game starts
            ball.goto(randomStartingPosition, 360)

            #the 'apple' falls at the random speed
            ballydirection = randomStartingSpeed 

            #clones the attributes of ball and assigns it ballTwo
            ballTwo = ball.clone()

            ballTwo.goto(randomStartingPositionTwo, 360)

            ballTwoydirection = randomStartingSpeedTwo

            #clones the attributes of ball and assigns it ballThree
            ballThree = ball.clone()

            ballThree.goto(randomStartingPositionThree, 360)

            ballThreeydirection = randomStartingSpeedThree

            #clones the attributes of ball and assigns it ballFour
            ballFour = ball.clone()

            ballFour.goto(randomStartingPositionFour, 360)

            ballFourydirection = randomStartingSpeedFour

            #creates a turtle for the initial score
            scoreText = turtle.Turtle()

            scoreText.color("#FF69B4")

            scoreText.penup()

            scoreText.hideturtle()

            scoreText.goto(0, 250)

            #writes 'Score: 0' in the center of the screen
            scoreText.write("Score: 0", align = 'center', font = ("Times New Roman", 16, "bold"))

            #collect key-events like onkeypress(). Source: https://docs.python.org/3/library/turtle.html#turtle.listen                  
            screen.listen()

            #whenever the left arrow is pressed, the function 'playerLeft' is called.
            screen.onkeypress(playerLeft, "Left")

            #whenever the right arrow is pressed, the function 'playerRight' is called.
            screen.onkeypress(playerRight, "Right")

            #initializes the variable 'score' to 0
            score = 0

        if level == 2 and score == 425:

            #sets level to 3, begins third level which makes the food and background different, and increase the food's speed
            level = 3

            screen.clear()

            screen.bgcolor("black")

            screen.addshape("ChickenCatchLevelThreeText.gif")

            levelText = turtle.Turtle()

            levelText.shape("ChickenCatchLevelThreeText.gif")

            time.sleep(2)

            screen.clear()

            #randomly selects an inital x coordinate for the first ball between -220 and 220 with a step of 20 pixels. 
            randomStartingPosition = random.randrange(-220, 220, 20)

            #randomly selects an inital x coordinate for the second ball between -220 and 220 with a step of 20 pixels.
            randomStartingPositionTwo = random.randrange(-220, 220, 20)

            #randomly selects an inital x coordinate for the third ball between -220 and 220 with a step of 20 pixels.
            randomStartingPositionThree = random.randrange(-220, 220, 20)

            #randomly selects an inital x coordinate for the fourth ball between -220 and 220 with a step of 20 pixels.
            randomStartingPositionFour = random.randrange(-220, 220, 20)

            #randomly selects an intial speed for the first ball between -6 and -1. (The range is negative because this variable is also for the direction it travels, so a negative number ensures it travels downward.)
            randomStartingSpeed = random.randrange(-10,-1)

            #randomly selects an intial speed for the second ball between -6 and -1.
            randomStartingSpeedTwo = random.randrange(-10,-1)

            #randomly selects an intial speed for the third ball between -6 and -1.
            randomStartingSpeedThree = random.randrange(-10,-1)

            #randomly selects an intial speed for the fourth ball between -6 and -1.
            randomStartingSpeedFour = random.randrange(-10,-1)

            screen.title("Chicken Catch")

            screen.bgpic("ChickenCatchBackgroundImageLevelThree.gif")

            screen.addshape("ChickenCatchFriesImage.gif")

            #changes the width and the height of the screen
            screen.setup(width = 500, height = 675)


            #creates a turtle for the 'basket' that the player controls
            player = turtle.Turtle()

            player.speed(0)

            player.shape("ChickenCatchPlayerImageRight.gif")

            player.shapesize(stretch_wid = 0.75, stretch_len = 3.5)

            player.penup()

            player.goto(0, -275)

            #creates a turtle for the first 'apple' that the player must catch
            ball = turtle.Turtle()

            ball.shape("ChickenCatchFriesImage.gif")

            ball.penup()

            #goes to a random inital position each time the game starts
            ball.goto(randomStartingPosition, 360)

            #the 'apple' falls at the random speed
            ballydirection = randomStartingSpeed 

            #clones the attributes of ball and assigns it ballTwo
            ballTwo = ball.clone()

            ballTwo.goto(randomStartingPositionTwo, 360)

            ballTwoydirection = randomStartingSpeedTwo

            #clones the attributes of ball and assigns it ballThree
            ballThree = ball.clone()

            ballThree.goto(randomStartingPositionThree, 360)

            ballThreeydirection = randomStartingSpeedThree

            #clones the attributes of ball and assigns it ballFour
            ballFour = ball.clone()

            ballFour.goto(randomStartingPositionFour, 360)

            ballFourydirection = randomStartingSpeedFour

            #creates a turtle for the initial score
            scoreText = turtle.Turtle()

            scoreText.color("#FF69B4")

            scoreText.penup()

            scoreText.hideturtle()

            scoreText.goto(0, 250)

            #writes 'Score: 0' in the center of the screen
            scoreText.write("Score: 0", align = 'center', font = ("Times New Roman", 16, "bold"))
            
            #collect key-events like onkeypress(). Source: https://docs.python.org/3/library/turtle.html#turtle.listen                  
            screen.listen()

            #whenever the left arrow is pressed, the function 'playerLeft' is called.
            screen.onkeypress(playerLeft, "Left")

            #whenever the right arrow is pressed, the function 'playerRight' is called.
            screen.onkeypress(playerRight, "Right")

            #initializes the variable 'score' to 0
            score = 0

        #once level 3 is completed, it displays the ending cutscene and bring the user to the title screen.
        if level == 3 and score == 625:

            screen.clear()

            screen.setup(width = 700, height = 450)

            endingCutscene = turtle.Turtle()

            for counter in range(1,11):

                endingCutscene.shape("ChickenCatchEndingCutsceneImage" + str(counter) + ".gif")

                if counter <= 3:

                    time.sleep(2.25)

                else:

                    time.sleep(1.25)


            time.sleep(2)

            screen.bye()

            window = Tk()

            window.geometry("500x725")

            window.title("Chicken Catch")

            bg = PhotoImage(file = "ChickenCatchTitleScreenBackground_V1.gif")

            canvas = Canvas(width = 500, height = 725)

            canvas.create_image(0, 0, image = bg, anchor = "nw")

            gameButton = Button(text = "Play Game!", command = chickenCatchGame, width = 25, height = 3, fg = "black", bg = "#FF69B4")

            gameButtonCanvas = canvas.create_window(170, 250, anchor = "nw", window = gameButton)

            instructionsButton = Button(text = "Instructions", command = instructionScreen, width = 25, height = 3, fg = "black", bg = "#FF69B4")

            instructionsButtonCanvas = canvas.create_window(170, 350, anchor = "nw", window = instructionsButton)

            creditsButton = Button(text = "Credits", command = creditScreen, width = 25, height = 3, fg = "black", bg = "#FF69B4")

            creditsButtonCanvas = canvas.create_window(170, 450, anchor = "nw", window = creditsButton)

            quitButton = Button(text = "Quit Game", command = window.destroy, width = 25, height = 3, fg = "black", bg = "#FF69B4")

            quitButtonCanvas = canvas.create_window(170, 550, anchor = "nw", window = quitButton)

            canvas.grid(row = 0, column = 0)

            window.mainloop()


#deletes the previous screen and displays the title screen. Source: https://www.tutorialspoint.com/how-to-clear-tkinter-canvas
def titleScreen():

    global canvas

    global window

    canvas.delete("all")

    bg = PhotoImage(file = "ChickenCatchTitleScreenBackground_V1.gif")

    canvas = Canvas(window, width = 500, height = 725)

    canvas.create_image(0, 0, image = bg, anchor = "nw")

    gameButton = Button(window, text = "Play Game", command = chickenCatchGame, width = 25, height = 3, fg = "black", bg = "#FF69B4")

    gameButtonCanvas = canvas.create_window(170, 250, anchor = "nw", window = gameButton)

    instructionsButton = Button(window, text = "Instructions", command = instructionScreen, width = 25, height = 3, fg = "black", bg = "#FF69B4")

    instructionsButtonCanvas = canvas.create_window(170, 350, anchor = "nw", window = instructionsButton)

    creditsButton = Button(window, text = "Credits", command = creditScreen, width = 25, height = 3, fg = "black", bg = "#FF69B4")

    creditsButtonCanvas = canvas.create_window(170, 450, anchor = "nw", window = creditsButton)

    quitButton = Button(window, text = "Quit Game", command = window.destroy, width = 25, height = 3, fg = "black", bg = "#FF69B4")

    quitButtonCanvas = canvas.create_window(170, 550, anchor = "nw", window = quitButton)

    canvas.grid(row = 0, column = 0)

    window.mainloop()

#deletes the previous screen and displays the instructions screen
def instructionScreen():

    global canvas

    global window

    canvas.delete("all")

    bg = PhotoImage(file = "ChickenCatchClearScreen.gif")

    canvas = Canvas(window, width = 500, height = 725)

    canvas.create_image(0, 0, image = bg, anchor = "nw")

    backButton = Button(window, text = "Back To Title Screen", command = titleScreen, width = 20, height = 2, fg = "black", bg = "#FF69B4")

    backbuttonCanvas = canvas.create_window(10, 10, anchor = "nw", window = backButton)

    storyLabel = Label(canvas, text = """Uh No!

Colonel Sander's bucket of food is falling!

Your mission as Mr. Flanagan is to catch every piece of food
before it touches the ground.

Catch all the food throughout the multiple levels and locations,
and you'll treated to a special surprise!
""", fg = "black", bg = "#FF69B4", borderwidth = 2, relief = "ridge")

    storyLabelCanvas = canvas.create_window(90, 190, anchor = "nw", window = storyLabel)

    #creates label for controls with border: https://stackoverflow.com/questions/39416021/border-for-tkinter-label
    instructionsLabel = Label(canvas, text = """To move Mr. Flanagan:

use the LEFT ARROW KEY >

and the RIGHT ARROW KEY <


To complete each level you need:

Level 1: 225

Level 2: 425

Level 3: 625""", fg = "black", bg = "#FF69B4", borderwidth = 2, relief = "ridge")

    instructionsLabelCanvas = canvas.create_window(170, 400, anchor = "nw", window = instructionsLabel)

    flanImage = PhotoImage(file = "ChickenCatchPlayerImageRight.gif")

    flanImageCanvas = canvas.create_image(40, 515, image = flanImage, anchor = "nw")

    canvas.grid(row = 0, column = 0)

    window.mainloop()

#deletes the previous screen and displays the credits screen
def creditScreen():

    global canvas

    global window

    canvas.delete("all")

    bg = PhotoImage(file = "ChickenCatchClearScreen.gif")

    canvas = Canvas(window, width = 500, height = 725)

    canvas.create_image(0, 0, image = bg, anchor = "nw")

    backButton = Button(window, text = "Back To Title Screen", command = titleScreen, width = 20, height = 2, fg = "black", bg = "#FF69B4")

    backbuttonCanvas = canvas.create_window(10, 10, anchor = "nw", window = backButton)

    purposeLabel = Label(canvas, text = """Purpose

The purpose for making this program is to make an enjoyable game
for users that love simple, but rewarding games.
As well, to showcase a fun story that relates to the gameplay.

If you sound like the user I mentioned above,
Chicken Catch will be a high-speed adventure that you will love.
""", fg = "black", bg = "#FF69B4", borderwidth = 2, relief = "ridge")

    purposeLabelCanvas = canvas.create_window(70, 150, anchor = "nw", window = purposeLabel)

    creditsLabel = Label(canvas, text = """Credits


Game Developer - Dharshaan Murari

Game Designer - Dharshaan Murari

UI Designer - Dharshaan Murari

UX Tester - Dharshaan Murari

Level Designer - Dharshaan Murari

Quality Assurance Tester - Dharshaan Murari


This Game Is Not Sponsored by KFC

""", fg = "black", bg = "#FF69B4", borderwidth = 2, relief = "ridge")

    creditsLabelCanvas = canvas.create_window(130, 400, anchor = "nw", window = creditsLabel)

    canvas.grid(row = 0, column = 0)

    window.mainloop()

#displays the title screen intially 
window = Tk()

window.geometry("500x725")

window.title("Chicken Catch")

bg = PhotoImage(file = "ChickenCatchTitleScreenBackground_V1.gif")

canvas = Canvas(window, width = 500, height = 725)

canvas.create_image(0, 0, image = bg, anchor = "nw")

gameButton = Button(window, text = "Play Game!", command = chickenCatchGame, width = 25, height = 3, fg = "black", bg = "#FF69B4")

gameButtonCanvas = canvas.create_window(170, 250, anchor = "nw", window = gameButton)

instructionsButton = Button(window, text = "Instructions", command = instructionScreen, width = 25, height = 3, fg = "black", bg = "#FF69B4")

instructionsButtonCanvas = canvas.create_window(170, 350, anchor = "nw", window = instructionsButton)

creditsButton = Button(window, text = "Credits", command = creditScreen, width = 25, height = 3, fg = "black", bg = "#FF69B4")

creditsButtonCanvas = canvas.create_window(170, 450, anchor = "nw", window = creditsButton)

quitButton = Button(window, text = "Quit Game", command = window.destroy, width = 25, height = 3, fg = "black", bg = "#FF69B4")

quitButtonCanvas = canvas.create_window(170, 550, anchor = "nw", window = quitButton)

canvas.grid(row = 0, column = 0)

window.mainloop()


        

        
